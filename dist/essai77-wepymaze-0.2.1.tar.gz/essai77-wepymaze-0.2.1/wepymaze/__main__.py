from .app import Application


def main():
    app = Application()
    app.start()
    
if __name__ == "__main__":
    main()