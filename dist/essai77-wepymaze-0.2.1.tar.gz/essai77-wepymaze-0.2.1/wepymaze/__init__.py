__author__ = "Thierry Chappuis"
__email__ = "tchappui@gmail.com"
__version__ = "0.2.1"
