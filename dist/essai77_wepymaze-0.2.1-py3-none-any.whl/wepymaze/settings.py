from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent

PASSAGE = '.'
WALL = '#'
START = 'S'
EXIT = 'X'